import React, { Component } from 'react';




// Week1Day3 Q/A props - components video ~25 minutes in

class PersonCard1 extends Component {
    constructor(props) {
        super(props);
        console.log(props);

        //setting state initially (immutable)
        //If you never change
        this.state = {
            age: this.props.age
        };
    }

    haveBirthday = () => {
        let birthday = this.state.age + 1
        // console.log(this.props.firstName + " had a birthday")
        // console.log({ birthday })

        //change of state
        this.setState({
            age: birthday
        })
    }
    render() {
        return (
            <>
                <h2>{this.props.lastName}, {this.props.firstName}</h2>
                <p>Age: {this.state.age}</p>
                <p>Hair Color: {this.props.hairColor}</p>
                <button onClick={this.haveBirthday}> Have Birthday </button>
            </>
        )
    }





}


export default PersonCard1;
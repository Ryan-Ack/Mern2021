import React from 'react';

import './App.css';
import Header from './components/Header';
import NavBar from './components/NavBar';
import PersonCard1 from './components/PersonCard1'
import MyNewComponent from './components/MyNewComponent';
import LightSwitch from './components/Lightswitch';


function App() {

  //const people=[{firstName="Ryan", lastName="Ackerman", age=30,hairColor="Blonde"}, {other object etc}]
  //run a .map of "people" instead of inputting personcard1 variables in each.


  return (
    <div>
      <Header someText={"Hello world from app.js"} />
      <LightSwitch />

      <PersonCard1 firstName={"Ryan"} lastName={"Ackerman"} age={30} hairColor={"Blonde"} />


      <PersonCard1 firstName={"John"} lastName={"Smith"} age={28} hairColor={"Black"} />

      <PersonCard1 firstName={"Samuel"} lastName={"Jackson"} age={26} hairColor={"Brown"} />
      <PersonCard1 firstName={"Tallie"} lastName={"Woodson"} age={24} hairColor={"Brown"} />

      <h1>Hello World!</h1>
      <NavBar />
      <hr />
      <NavBar />

      <MyNewComponent header={"Header Prop"}>
        <p>This is a child</p>
        <p>This is another child</p>
        <p>This is even another child</p>
      </MyNewComponent>


    </div>
  );

}
export default App;

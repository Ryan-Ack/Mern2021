import React, { Component } from 'react';

class BirthdayButton extends Component {

    constructor(age) {
        super(age);
        this.state = {
            age: { age }
        };
    }

    haveBirthday = () => {
        this.setState = this.props.age + 1
        console.log("had birthday")
    }

    render() {
        return (
            <>
                <button onClick={this.haveBirthday}> Have Birthday </button>
            </>
        )
    }



}
export default BirthdayButton;
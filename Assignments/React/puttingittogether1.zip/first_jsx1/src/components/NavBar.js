import React, { Component } from 'react';


class NavBar extends Component {
    render() {
        return (
            <>

                <h3>Its Always Casual</h3>
                <ul>
                    <li>Overall</li>
                    <li>Gathering</li>
                    <li>Artisan</li>
                    <li>Combat</li>
                    <li>Support</li>

                </ul>
            </>
        )
    }
}
export default NavBar;
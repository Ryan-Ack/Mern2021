import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <div>
                <h1>This is my Header from the header component</h1>
                {this.props.someText}
            </div>
        )
    }
}


export default Header;